package com.solution.parkeasy

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ParkingSpotApplication : Application()